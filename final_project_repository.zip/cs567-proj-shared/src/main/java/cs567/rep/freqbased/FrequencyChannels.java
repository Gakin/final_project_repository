package cs567.rep.freqbased;

public class FrequencyChannels {
	public float[][] red;
	public float[][] green;
	public float[][] blue;
}
